using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using uFrame.IOC;
using uFrame.Kernel;
using uFrame.MVVM;
using System.Reflection;


public class UserManagementSystemLoader : UserManagementSystemLoaderBase {
    
    public override void Load() {
        base.Load();
    }
}
